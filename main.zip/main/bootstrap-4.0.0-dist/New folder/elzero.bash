npx create-react-app my-react-app
cd my-react-app
