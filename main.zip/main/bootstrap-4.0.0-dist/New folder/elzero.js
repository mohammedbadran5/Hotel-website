/*function moha(...num){
    var b=0
    for(var a=0 ; a<num.length ; a++){
        b+=num[a]
        document.write("\n"+b)
    }
}
document.write(moha(10,2,20,30))*/






/*function outerFunction() {
    document.write("This is the outer function.<br>");
  
    function innerFunction() {
      document.write("This is the inner function.<br>");
    }
  
    // Call the inner function from the outer function
    innerFunction();
  }
  
  // Call the outer function
  outerFunction();*/







/*function moha(){

    let a=10;

    function moha2()

    {
        document.write(a);

        function moha3()
        {
            let b=100;
            document.write(a);
            document.write(b);
        }
        moha3()
    }
    moha2()
}
moha()*/



/*function moha(...name){
    return name;
}
document.write(moha("mohammed","omar","saeed","ali"))*/


//-------------------MAP---------------------------

/*var a=[1,2,3,4,5]
let b=a.map((a) => a+a)
document.write(b)   //هي بديل عن الدوران بتقدر تعمل عمليات على المحتوى تبع الاراي بدون دوران*/





/*function swapCase(text) {
    return text.replace(/([a-z])|([A-Z])/g, function(match, lower, upper) {
      return lower ? match.toUpperCase() : match.toLowerCase();
    });
  }
  
  var originalText = "Hello World 123";
  var swappedText = swapCase(originalText);
  document.write("Original Text: " + originalText);
  document.write("Swapped Text: " + swappedText);*/






/*var a=[-1,2,-3,4,5]
for(var b=0 ; b<a.length ; b++){
    var c=a[b] *-1
    document.write(c)
}*/




/*function a(b) {
    return b.replace(/\d+/g, '');
}
document.write("String without Numbers: " + a("Hello 123 World 456"));*/




/*const numbers = [1, 5, 10, 15, 20, 25, 30];
const a = numbers.filter(function(number) {
  return number > 10;
});

document.write("Filtered numbers array: " + a);*/






/*function a(inputString) {
    const numbersArray = inputString.split(/\D+/).filter(Boolean);
    const numbers = numbersArray.map(Number);
    return numbers;
}
document.write("Extracted Numbers: " + a("There are 3 numbers in this string: 5, 10, and 15."));*/



/*const numbers = [1, 2, 3, 4, 5];
const sum = numbers.reduce((accumulator, currentValue) => {
    return accumulator + currentValue;
}, 0);
document.write(sum); // Output will be 15*/




/*const words = ["apple", "banana", "cherry", "date", "fig"];

const longestWord = words.reduce((currentLongest, currentWord) => {
  if (currentWord.length > currentLongest.length) {
    return currentWord;
  } else {
    return currentLongest;
  }
}, "");

console.log(longestWord); // Output will be "banana"*/



/*var a=["ali","omar","mohammed"]
var max=""
for (var b=0 ; b<a.length ; b++){
    if(a[b].length > max.length){
        max=a[b]
    }
}
document.write(max)*/




/*const charArray = ['a', 'b', 'c', 'd', 'e'];
const charToRemove = 'c';
const filteredArray = charArray.filter(char => char !== charToRemove);
document.write(filteredArray); // Output will be ['a', 'b', 'd', 'e']*/





/*const inputString = "Hello, [World] 123!";
const stringWithoutSymbols = inputString
  .split('')   .filter(char => /[a-zA-Z]/.test(char))   .join('');

document.write(stringWithoutSymbols); // Output will be "Hello World"*/




//-------------------------OBJECT---------------------------------

/*
let a={
    name:"badran",
    age:21,
    avail:"false",
    skills:["css","html","js"],
    address : {
        add1:"amman",
        irbid:{
            add2:"bushra",
        },
    },
   check: function(){
    if(avail=true){
        return "free"
    }
    else{
        return "not free"
    }
   },
};


document.write(a.name+"\n")
document.write(a.age+"\n")
document.write(a.check()+"\n")
document.write(a.skills.join(" | ")+" ")
document.write(a.address.add1)
a.tall="183"
document.write(a.tall)*/





/*function sayHello() {
    console.log(`Hello, ${this.name}!`);
  }
  
  const person = { name: "John" };
  
  document.write(sayHello.call(person)); // "Hello, John!"
  sayHello.apply(person); // "Hello, John!"
  const greetJohn = sayHello.bind(person);
  document.write(greetJohn()); // "Hello, John!"*/







/*let a=document.getElementById("my-div");//get the id content
let b=document.getElementsByTagName("p")//get all the p
let d=document.getElementsByClassName("my-span")
let s=document.querySelector("#my-div")
let r=document.querySelector(".my-span")
console.log(r)//he will print the first span to print every span we use queryselectorAll
console.log(s)
console.log(b)//print all p
console.log(a)//print the my-div content
console.log(d)//print the class "my-span"
console.log(b[1])//print the second p
b[1].innerHTML="text"//change the second p content
b[1].innerHTML="text"//change the second p content
console.log(document.forms[0].one.value)//to print the first form and print the value of this form"hello"

//the query selector can do all if the above tasks in one line 
//in class we put (.) in id we put (#)*/







/*let a=document.querySelector(".js")
console.log(a.innerHTML)//print the all line
console.log(a.textContent)//print the text content
//to edit the text in the js class
a.innerHTML="text from <span> elzero.js </span> file"//change it as a structure
a.textContent="text from <span> elzero.js </span> file"//change it as a text
document.images[0].alt="alter"
document.images[0].src="https://thumbs.dreamstime.com/b/beach-sea-18378306.jpg"//to change the image in your website.
document.images[0].id="pic"//add an idd to the element in the elemnt in the inspect
//to change the link 
let b=document.querySelector(".link")
b.setAttribute("href","http://twitter.com")//here you make the link go the twitter app not to googl*/




/*console.log(document.getElementsByTagName("p")[0].attributes)//to get the (p)
let b=document.getElementsByTagName("p")[0];
if(b.hasAttribute("data-src")){//you check if the a(P) have the data-src and it its true
  console.log("found");
  b.removeAttribute("data-src")//here we remove the data-src
}else{
  console.log("not found")
}*/




//how to create a new element 
/*let a=document.createElement("div")//create a div
a.className="product"//give a div a classname called product
let b=document.createTextNode("product one")//create a text called prduct one
let c=document.createAttribute("data-custom")//make thebtext insude data-costum
a.setAttributeNode(c)
a.setAttribute("data-test","testing")
a.appendChild(b)
document.body.appendChild(a)//print the text in doc.write
console.log(b)
console.log(a)*/






/*let a=document.createElement("div")
let b=document.createElement("h2")
let c=document.createElement("p")

let d=document.createTextNode("product title")
let e=document.createTextNode("product  description")
b.appendChild(d)//add headig text
a.appendChild(d)//add heading to main element
c.appendChild(e)//add paragraph text
a.appendChild(c)

a.className="product";
document.body.appendChild(a)*/




/*let a=document.querySelector("div")
console.log(a )//print the div content as a text
console.log(a.children[0])//prin the first elemnt in the div(hello div)
console.log(a.childNodes)//all div content as a data type
console.log(a.firstChild)//first component in the div*/




//---------------onclick---------------
/*let a=document.getElementById("btn")
a.onclick=function(){
  console.log('clicked')*/

/*let userin=document.querySelector("[name='username']");
let agein=document.querySelector("[name='age']")


document.forms[0].onsubmit=function(e){
  let user=false;
  let age=false;


if(userin.value !== "" && userin.value.length <=10){
  user=true;
  
}else{
  alert("unvalid number")
}


if(agein.value !==""){
  age=true;
}


  if(user==false || age==false){
    e.preventDefault();
  }

}

document.links[0].onclick=function(a){
  console.log(a)
  event.preventDefault();//here you make the link unclickable
}*/




/*10 let two=document.querySelector(".two")
let one=document.querySelector(".one")

window.onload=function(){
  two.focus();
}

one.onblur=function(){
  document.links[0].click();
}*/





//how to control the css prob in the js

/*11 let a=document.getElementById("my-div")
a.style.background="red"
a.style.fontSize="30px"
//to put all styles in one line
a.style.cssText="fontsize:30px ; color:green ; font-weight:bold"
//هسا رح نحكي عن ازالة او تعديل خاصية محددة مع اداء اكشن معين
a.style.removeProperty("color")//هيك شلنا اللون 
a.style.setProperty("font-size","50px")//هيك احنا عدلنا عالخاصية
document.styleSheets[0].rules[0].style.removeProperty("font-size")//احنا هيك بنشيل خصائص من ال css*/








/*  project let a=document.getElementById("me")
let b=document.getElementById("me2")
let c=document.querySelector("p")
let d=document.querySelector("h1")

a.style.cssText="background:rgb(236,236,236) ; width:700px ; height:600px"
b.style.cssText="background:white; position:relative ; left:10px; top:10px ; width:220px;height:95px;text-align:center;font-family:Tahoma, Arial"
c.style.cssText="position:relative;top:10px;font-size:40px;"
d.style.cssText="position:relative;top:-22px;font-size:17px;font-weight: 1;opacity:.7" */









//كيف اشيل عنصر او نص
/* 12 let a=document.getElementById("my-div")
let b=document.createElement("p")
a.remove();*/




/*  13  let span=document.querySelector(".two")
console.log(span.nextElementSibling.remove())//هيك انا بشيل العنصر الي بعدال two
console.log(span.previousElementSibling.remove())//ازالة الي قبل الtwo


console.log(span.parentElement)
span.onclick=function(){
  span.parentElement.style.opacity='0'//بس اكبس عليها بتختفي
}*/





//whe  we click on something

/* 14  let a=document.querySelector("p")
a.onclick=one;
a.onclick=two;

function one(){  
  console.log("message from onclick 1")  //when click on clone me the message appear
}

function two(){ 
  console.log("message from onclick 2")  //when click on clone me the message appear
}

window.onload="badran";

a.addEventListener("click",function() { //print without calling
  console.log("message from onclick 1 event")
})

a.addEventListener("click",one)//calling function one
a.addEventListener("click",two)//calling function two*/















//--------------------BOM---------------------


/* 1 without html code         let a=confirm("are you sure ?")//use prompt بدل confirm to let the user write an input
console.log(a)

if(a==true){ //if true so the user want to do this action
  console.log("item deleted")
}
else{
  console.log("item not deleted")
}*/




//now how to make a move after a time

/*  2 without a html code   setTimeout(function(){
  console.log('msg');
},3000);//3000 means 3 second*/






/*  3   setInterval(function()  {
  console.log("msg")
}, 2000);//every 2 second he will print "msg"*/






/*  4  let a=document.querySelector("div")
function countdown(){
  a.innerHTML-=1;
  if(div.innerHTML=="0"){
    clearInterval(counter)
  }
}

let b=setInterval(countdown,1000)  //here we create a counter like the happy new year count down*/





//كيف نظهر مربع بابعاد معينة فيو محتوى 
/*   5  without html 
setTimeout(function(){
  window.open("https://google.com","_blank","width=400,height=400,top=200,left=400");
},2000);*/







//--------------------destructure arrays------------

/*  1  without html
let a=1;
let b=2;
let c=3;
let d=4;

let my=["ali","ahmad","sosan","sara"];

[a="A",b,c,d,e]=my

console.log(a)
console.log(b)
console.log(c)
console.log(d)
console.log(e)

let[,y, ,z]=my;
console.log(y);
console.log(z)
*/






/*  2 without html   let my=["ali","safe","ali",["shady","amr",["mohammed","gamal"]]];
//console.log(my[3][2][1])
let[, , , [, , [, b]]]=my;
console.log(b) //another way to print gamal
*/



/* without html code   -----       how to check if the element is in the list and how to clear and check  

let mydata=[1,1,1,2,3]

let myuniquedata=new Set();

myuniquedata.add(1).add(1).add(1);
myuniquedata.add(2).add(3);

console.log(mydata);
console.log(myuniquedata);

console.log(myuniquedata.size);

console.log(mydata[0]);
console.log(myuniquedata[0]);


console.log(myuniquedata.delete(2))//انوالعنصر 2 موجود
console.log(myuniquedata.size);
console.log(myuniquedata)


myuniquedata.clear()//بتخلي طول اللليست يكون 0
console.log(myuniquedata);
console.log(myuniquedata.size)


console.log(myuniquedata.has(1)) //return false because we clear the list content
*/









/*const person = {
  firstName: 'John',
  lastName: 'Doe',
  age: 30,
};

// Destructuring the object
const { firstName, lastName, age } = person;

console.log(firstName); // Output: John
console.log(lastName);  // Output: Doe
console.log(age);       // Output: 30*/





/* without html code 
let myobject={};
let myemptyobject=Object.create(null);
let mymap=new Map(); 

console.log(myobject);
console.log(myemptyobject);
console.log(mymap);


let mynewobject = {
  10:"number",
  "10":"string"
}
console.log(mynewobject[10])//the last 10

let mynewmap=new Map();
mynewmap.set(10,"number");
mynewmap.set("10","string")
console.log(mynewmap.get(10))//the first 10

*/




/*without html code
let mymap=new Map([//the same output of the mymap.set();
  [10,"number"],
  ["name","string"], 
  [false,"boolean"]
]);

mymap.set(10,"number")
mymap.set("name","string");
console.log(mymap);

console.log(mymap.get(10)); //the number : 10 he print it as a number 
console.log(mymap.get("name")); //he take the neighberhood of "name"
console.log(mymap.get(false));


console.log(mymap.has("name"));


console.log(mymap.size);
console.log(mymap.delete("name"));//will  return true that mean that is the code seccussfully delete the "name";
console.log(mymap.size)//the size after delete the name;

mymap.clear();
console.log(mymap.size);//the size after clear th set contennt is 0;
console.log(mymap.has("name"));//after clear there is no "name";
*/








// ---------------------array------------------


/*
console.log(Array.from("badran"))//seperate the text; 

console.log(
  Array.from("12345",function(n){//to sum the same number in an array
    return +n + +n;
  })
);


console.log(Array.from("12345", (n) => +n + +n)) //another way to sum the same number;
*/



//--------------some1----------


/*
let nums=[1,2,3,4,5,6,7,8,9];

let mynum=10;


let check = nums.some(function(e){
  console.log("test");//he print 6 test until he arrive the number 6 that is bigger than 5
  return e>5;
});

console.log(check)

/*
let check=nums.some((e) => e > 5); // another way to check the condition
*/





//--------------some2----------


/*
let num=[1,2,3,4,5,6,7,8,9,10];
let mynum=10;

let check=num.some(function(e){
  return e>this;
},mynum);

console.log(check)


function checkvalues(arr,val){
  return arr.some(function(e){
    return e==val;
  })
}

console.log(checkvalues(num,20));//the number 20 is not in the list
*/






//---------------every-------------------
/*
const locations = {
  20:"place1",
  30:"place2",
  10:"place3",
  40:"place4",
};

let mainlocation=15;

let locationarrray=Object.keys(locations);
console.log(locationarrray); //convert the set to a list as a string

let locationarrraynumber=locationarrray.map((n) => +n)
console.log(locationarrraynumber)//convert the set to a list of numbers
*/






/*
console.log("osama");//print osama
console.log(..."osama");//print seperate osama
console.log([..."osama"])//convert "osama" to a array;


let array1 = [1,2,3];
let array2 = [4,5,6];
let allarray = [...array1 , ...array2];//
console.log(allarray) //mix the two element arrays



let a = ["osama","ahmad","sayed"];
let b = ["sameh","mahmoud"];
a.push(...b) //add the second array items to the first array
console.log(a)



let num = [10,20,-100,100,340,1000];
console.log(Math.max(...num)); //find the max number in the array



let obj1 = {
  a:1,
  b:2,
};
let obj2 = {
  c:3,
  d:4,
};

console.log({...obj1 , ...obj2}) //mix two object 
*/









//---------------regular expression----------------
/*
let mystr = "hello Elzero web school i  love elzero";

console.log(mystr.match(/elzero/)) //show you in which index "elzero" is
console.log(mystr.match(/elzero/ig)) //all the similer result
*/





/*
let tld = "com net org info code io";
let tldre = /(info|org|io)/i 
console.log(tld.match(tldre));//he will search just one of them if he exist or not


let tldre2 = /(info|org|io)/ig//all of them by "ig" all of them if they exsist or not
console.log(tld.match(tldre2));


let num="0123456789"
let numre = /[0-9]/ //to check in email if any of these number are exist
console.log(num.match(numre))


let numre2=/[^2-5]/g //every number exept the numbers between 2-5
console.log(num.match(numre2))


let num2 = "0!1#2$3&456789"
let numre3 = /[^0-9]/g //will return all symbols .. "^" this symbols means dont give me any thing in this range
console.log(num2.match(numre3))


let num3 = "os1 os10 os2 os8 os8os";
let numre4 = /os[5-9]os/g
console.log(num3.match(numre4)); //give me the string with os8os
*/







/*
let mystring="AaBbcdefG123!234%^&*";
let b = /[a-z]/g  //all small letters from a-z
console.log(mystring.match(b))


let c=/[A-Z]/g //all capital letters from A-Z
console.log(mystring.match(c)); 


let d=/[^A-Z]/g //every thing exept the capital
console.log(mystring.match(d)); 


let e=/[^ace]/g //every thing exept the "ace"
console.log(mystring.match(e))


let f=/[A-Z-a-z]/g //every small and capital letters
console.log(mystring.match(f))


let g=/[^A-Z-a-z]/g //every thing exept letters
console.log(mystring.match(g))


let h=/[^0-9-A-Z-a-z]/g //just symbols
console.log(mystring.match(h))
*/








/*
let email = 'O@@@g...com O@g.com O@g.net A@Y.com O-g.com o@s.org 1@1.com';
let dot = /./g; //every thing have a dot seperate it to a letters;
let word = /\w/g; //give every thing except the dot ;
let valid = /\w@\w.com/g; //letter then @ then  .com
console.log(email.match(dot));
console.log(email.match(word));//every letter
console.log(email.match(valid));//every string have @
*/





/*
let names = "sayed 1spam 2spam 3spam spam spam5 osama ahmed";
let re=/spam/ig; //all spams (5 spams);
console.log(names.match(re))

let re2=/\bspam/ig; //just the string start with spam not with a number
console.log(names.match(re2))

let re3=/spam\b/ig; 
console.log(names.match(re3)) //end with spam


console.log(/(\bspam)/ig.test("spam1")) //spam1 come first before the number so its true
*/




/*
let mails="o@nn.sa osama@gmail elzero@gmail.net osama@mail.ru";

let mailre=/\w+@\w+/ig //have a letter then a "@" and then a letter 
console.log(mails.match(mailre))

let nums="0110 10 150 05120 0560 350 00"
let numsre=/0\d+0/ig;  //zero the digit then zero
console.log(nums.match(numsre))
*/




/*
let serial = "s100s s3000s s500000s s9500000s"
console.log(serial.match(/s\d{3}s/ig))//start with s then 3 digit then ene dwith zero
console.log(serial.match(/s\d{4,7}s/ig))//start with s then a range of numbers from 4-7 then ends with s;
console.log(serial.match(/s\d{3,}s/ig))//start with s then at least 3 digit then ends with s
*/




/*
let mystring = "we love progtamming";
let names="10samaz 2ahmeddz 3mohammed 4mutafaz 5gamalz"

console.log(/ing$/ig.test(mystring))//if the string end with ing "true"
console.log(/^we/ig.test(mystring))//if the string start with we "true";
console.log(/lz$/ig.test(names)) //if the names have a "lz" at the end;
console.log(/^\d/ig.test(names));//if there is a digit in "names";
console.log(names.match(/\d\w/ig)) //digit then a letter
*/





/*
let txt="we love programming and @ because @ is amazing";
console.log(txt.replace("@","js"))//replace just one string;
console.log(txt.replaceAll("@","js"))//replace every @ in the string

let re=/@/ig;
console.log(txt.replaceAll(re,"js"))
console.log(txt.replaceAll(re,"js"))
console.log(txt.replaceAll(/@/ig ,"js"))//same thing
*/




/*  f1

document.getElementById("register").onsubmit=function() {
  let phoneinput=document.getElementById("phone").value;
  let phone=/0\d{9}/; //if the phoneinput start with 0 and the length is 10 
  let vlaidtionresult=phone.test(phoneinput)
  if(vlaidtionresult==false){
    alert("please enter a valid phone number")
  }
  return true;
}

*/






//-----------------OOP---------------
/*
function User(id,username,salary){
  this.i=id;
  this.un=username;
  this.s=salary+100; //we added a 100 doller to the salary for each input salary user; 
}

let userone=new User(100,"badran",5000);
let usertwo=new User(101,"hassan",6000);
let userthree=new User(102,"ahmed",7000);

console.log(userone.i)
console.log(userone.un);
console.log(userone.s);

console.log(usertwo.i);
console.log(usertwo.un);
console.log(usertwo.s);

console.log(userthree.i);
console.log(userthree.un);
console.log(userthree.s);
*/





/*
function User(id,username,salary){
  this.i=id;
  this.un=username;
  this.s=salary+100; //we added a 100 doller to the salary for each input salary user; 
}

let userone=new User(100,"badran",5000);

console.log(userone.i)
console.log(userone.un);
console.log(userone.s);

console.log(userone instanceof User); //true that user one part of user;
*/






/*
class User {  //the class code is same to the upper function code
  constructor(id, username, salary) {

    this.i = id;
    this.un = username;
    this.s = salary; //we added a 100 doller to the salary for each input salary user; 
  }
    updatename(newname) { //we here update the name from badran to osama;
      this.un = newname;
    }
}


let userone=new User(100,"badran",5000);

console.log(userone.un);
userone.updatename("osama");
console.log(userone.un)
*/




/*
class User {  //the class code is same to the upper function code
  static count=0;

  constructor(id, username, salary) {

    this.i = id;
    this.un = username;
    this.s = salary; //we added a 100 doller to the salary for each input salary user; 
    User.count++;
  }

  static sayhello() { //a method that print a "hello";
    return 'hello from class';
  }

  static countmemeber() {
    return `${this.count} members created`;
  }
}


let userone=new User(100,"badran",5000);
let usertwo=new User(101,"hassan",6000);

console.log(userone.un); //object
console.log(usertwo.un); //object
console.log(User.sayhello())
console.log(User.countmemeber()) //every user created the count add a 1 to the counter;
*/





/* inheritance
//parent class
class User {  //the class code is same to the upper function code
  constructor(id, username) {

    this.i = id;
    this.un = username;
}

  sayhello(){
    return `hello ${this.un}`;
  }
}

//derived class
class Admin extends User{  //the class code is same to the upper function code
  constructor(id, username, permission) {
    super(id,username); //you bring the id,username from the class "user";
    this.p = permission; //we added a 100 doller to the salary for each input salary user; 
  }

  sayhello(){
    return `hello ${this.un}`;
  }
}

class superemp extends Admin{
  constructor(id,username,permission,ability){
    super(id,username,permission);
    this.a=ability;
  }
}//repeat the code down for this class the same way




let userone=new User(100,"badran");
let adminone=new Admin(110,"ali",1)

console.log(userone.un);
console.log(userone.sayhello())
console.log("-------------")
console.log(adminone.i)
console.log(adminone.un);
console.log(adminone.p)
console.log(adminone.sayhello())
*/





/*
class User {
  #e; //private att;

  constructor(id,username,exepectedsalary) {
    this.i=id;
    this.u=username;
    this.#e=exepectedsalary;
  }

  getsalary() {
    return parseInt(this.#e); //return the number if you add a string;
  }
}

let userone=new User(100,"badran","5000 jd");

console.log(userone.u)
console.log(userone.getsalary() * 0.3) //تحويل عملة
*/






/*
class User {  //the class code is same to the upper function code
  constructor(id, username) {

    this.i = id;
    this.un = username;
}

  sayhello(){
    return `hello ${this.un}`;
  }
}

let userone=new User(100,"badran");
console.log(userone.un);

console.log(User.prototype) //give you info about the class;


console.log(String.prototype); //give you all string method;
*/







/*
const myobject = {
  a:1,
  b:2,
}

Object.defineProperties(myobject, {
  c: {
    configurable:true,
    value:3,
  },
  d: {
    configurable:true,
    value:4,
  },
  e: {
    configurable:true,
    value:5,
  },
})

console.log(myobject);

console.log(Object.getOwnPropertyDescriptor(myobject,"d")); //"d" information;
*/




//----------Date and Time------------------
/*
let datenow = new Date();
console.log(datenow); //give you the date
console.log(Date.now()); //in mille second;
console.log(Date.now()/1000); //in second;
console.log(Date.now()/10000); // in mintues;
console.log(Date.now()/60000);//in hours;
console.log(Date.now()/144000);//in days
*/





/*
let datenow=new Date();
let birthday=new Date("OCT 13 , 2002");

let datediff=datenow-birthday; //calc your age;
console.log(datediff/1000/60/60/24/365);//return your age;

console.log(datenow.getDate());//return the date of the month;
console.log(datenow.getTime());
console.log(datenow.getFullYear()); //return the current year;
console.log(datenow.getMonth()+1);
console.log(datenow.getHours());//the current hour
console.log(datenow.getMinutes());//the min
*/






/*
let datenow = new Date();
console.log(datenow);

console.log("#".repeat(46));

datenow.setTime(0);
console.log(datenow);

console.log("#".repeat(46));

datenow.setTime(10000);//after 10 second;
console.log(datenow);

datenow.setFullYear(2020,13);
console.log(datenow);
*/









/*
let date1 = new Date(0);
console.log(date1);

let date2 = new Date();
console.log(date2);

let date3 = new Date("2002 10 13");
console.log(date3);

let date4 = new Date();
console.log(date4);

let date5 = new Date();
console.log(date5);
*/






//-------------------Show More-----------
/*
function* generatenumbers() {
  yield 1;
  console.log("hello after yeild 1");
  yield 2;
  yield 3;
  yield 4;
}


let generator=generatenumbers()
console.log(typeof generator);
console.log(generator);

//console.log(generator.next())
//console.log(generator.next())
//console.log(generator.next())
//console.log(generator.next())
//console.log(generator.next())


//for (let value of generatenumbers()) {
  //console.log(value);
//}

for (let value of generator) {
  console.log(value);
}
*/






/*
function* generatenumbers() {
  yield 1;
  yield 2;
  yield 3;
}


function* generateletters() {
  yield "A";
  yield "B";
  yield "C";
}

function* generateall() {
  yield generateall();
  yield generateletters();
  yield [4,5,6];

}

let generatot =generateall();

console.log(generatot.next());
console.log(generatot.next());
console.log(generatot.next());
console.log(generatot.next());
console.log(generatot.next());
console.log(generatot.next());
*/













/*
let a=document.getElementById("btn")

a.onclick=function(){
  alert('clicked')
  a.style="color:red"
}
*/




/*24
var numofbutton =document.querySelectorAll(".drum").length;

for(var i=0 ; i<numofbutton ; i++){
  document.querySelectorAll(".drum")[i].addEventListener("click",function() {
    alert("hello badran")
  })
}
*/


/*
const buttons = document.querySelectorAll('.color-button');
let clickedCount = 0;

buttons.forEach((button, index) => {
  button.addEventListener('click', () => {
    // Change the color of the button
    button.style.backgroundColor = 'green';
    clickedCount++;

    if (clickedCount === buttons.length) {
      // All buttons have been clicked, change them all to red
      buttons.forEach((btn) => {
        btn.style.backgroundColor = 'red';
      });
    }
  });
});
*/






//------------------------jquery----------



$(document).ready(function() {
  $('#styleButton').click(function() {
   $('#textToChange')
      .text('bye') //change the text
      .css('color', 'red') //change the color
      .css('font-size', '30px'); //change the text size;
  });
});

$("a").attr("href","https://www.yahoo.com");//change the link

$("h1").click(function (){
  $("h1").css("color","red")//change the h1 color when click on it;
})

$(document).keypress(function(event){ //what even you write in the input field will apear in the white field.
  $("h1").text(event.key);
})

$(document).ready(function() {
  $("#hi2").click(function() {
   // $("#textToHide").hide();//hide the text by click on the button
   //$("#textToHide").slideToggle(); //test it to understand and you can to change the text show when the text go up;
   //$("#textToHide").animate({opacity:0.5})//change the opacity to the text when clikc on the button;
   //$("#textToHide").animate({margin:"20px"}) //change the margin ; and you can change the color and size and evert thing you want;
   //$("#textToHide").slideUp().slideDown().animate({opacity:0.5}) //we do 3 action test it;
  });
});




